package com.peisia.dto;

import lombok.Data;

@Data
public class UserDto {

	private String id;
	private String userName;
	private String pw;
	private String email;

}
