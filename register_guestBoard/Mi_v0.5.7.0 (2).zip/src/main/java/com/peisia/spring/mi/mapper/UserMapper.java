package com.peisia.spring.mi.mapper;

import com.peisia.dto.UserDto;

public interface UserMapper {

	public void register(UserDto user);
}
