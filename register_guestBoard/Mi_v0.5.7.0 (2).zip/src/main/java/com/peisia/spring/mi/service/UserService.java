package com.peisia.spring.mi.service;

import com.peisia.dto.UserDto;

public interface UserService {
	public void register(UserDto user);
}
